<div class="container">
    <p>Stran, ki ste jo želeli obiskati, ni na voljo.</p>
</div>